<? require_once 'apino.php' ?>
<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<title></title>
	</head>
	<body>
		<img style="width: 100%;" src="<?=Embed::ref('', Embed::apino('/student_special/selectOne'))?>" />
	</body>
</html>
